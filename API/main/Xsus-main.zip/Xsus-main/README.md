# Xsus
A Command Line Application Branched out from websites to packages all the way to node apps


All Credits go to me, BioShot.

# About: 

Xsus is a Solo Command Line Application Branched out from websites to packages all the way to node apps



# How To Use:
As Of Right Now, Xsus is not availible to the public. 
When it is released, You will see a Xsus.cmd & install.cmd . DO NOT RUN THE INSTALL.CMD IN COMMAND PROMPT IT DOES NOT INSTALL XSUS!!! ONLY XSUS.CMD SHOULD USE THIS!!!
The only reason why this Repository is public is so i can upload packages.
